#ifndef TRUFFLEDATA_JSON_DECODER_COMMON_H
#define TRUFFLEDATA_JSON_DECODER_COMMON_H
// Grammar, sizing, and validate-only writer shared by the structural producer and On-Demand oracle.
#include "tape/native/arena.h"
#include "tape/native/ctape.h"
#include "tape/native/index_memory.h"
#include <myna/values.hpp>
#include <simdjson.h>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <type_traits>

namespace truffledata::json {

inline std::string_view trim(std::string_view s) {
  while (!s.empty() && (s.back() == ' ' || s.back() == '\n' ||
                        s.back() == '\r' || s.back() == '\t')) s.remove_suffix(1);
  return s;
}

// RFC 8259 grammar, deliberately independent of machine numeric range.
inline bool number(std::string_view s) {
  size_t i = 0;
  auto digit = [&] { return i < s.size() && s[i] >= '0' && s[i] <= '9'; };
  if (i < s.size() && s[i] == '-') ++i;
  if (!digit()) return false;
  if (s[i] == '0') ++i;
  else while (digit()) ++i;
  if (i < s.size() && s[i] == '.') {
    ++i;
    if (!digit()) return false;
    while (digit()) ++i;
  }
  if (i < s.size() && (s[i] == 'e' || s[i] == 'E')) {
    ++i;
    if (i < s.size() && (s[i] == '+' || s[i] == '-')) ++i;
    if (!digit()) return false;
    while (digit()) ++i;
  }
  return i == s.size();
}

// A string body is "clean" when it has no backslash and no raw byte below 0x20: it is then
// referenced without get_string(). Stage 1 validated UTF-8 for the whole buffer before any body is
// referenced, and stage 1 also rejects raw control bytes; bodies failing this scan still go through
// get_string()/unescaped_key() so simdjson validates their escapes.
struct body_scan { bool clean; bool ascii; };
inline body_scan scan(std::string_view body) {
  unsigned char any = 0;
  for (unsigned char c : body) {
    if (c == '\\' || c < 0x20) return {false, false};
    any |= c;
  }
  return {true, any < 0x80};
}
inline bool ascii(std::string_view text) {
  unsigned char any = 0;
  for (unsigned char c : text) any |= c;
  return any < 0x80;
}

// Storage presizing from the input length (§3.4): input / 3 + 8 words, input / 8 + 64 pool bytes
// and words / 2 + 1 directory entries. Typical JSON has one word per 3-6 input bytes; the worst
// case (`[1,1,...]`) has one per byte, which grows the words once or twice. Hints never exceed two
// words per allowed value or a fixed share of the index budget, and depend only on the
// configuration, so a document's allocation sequence (and its exact index peak) is reproducible.
struct decode_hint {
  size_t words;
  size_t pool;
  size_t entries;
  size_t block;  // First arena block: the presized arrays that are not large allocations.
};
inline decode_hint hint_for(size_t input, const myna::value_limits& limits, const tape::storage_limits& storage) {
  size_t cap = storage.index_bytes / 32 > 4096 ? storage.index_bytes / 32 : 4096;
  size_t words = input / 3 + 8;
  if (words > cap) words = cap;
  if (limits.nodes < words / 2) words = static_cast<size_t>(limits.nodes) * 2 + 2;
  size_t pool = input / 8 + 64;
  if (pool > cap * 8) pool = cap * 8;
  size_t entries = words / 2 + 1;
  size_t pending = entries < 256 ? entries : 256;
  size_t block = 256;
  for (size_t part : {words * sizeof(uint64_t), pool, entries * sizeof(uint64_t), pending * sizeof(uint64_t)})
    if (part <= tape::block_arena::large_threshold) block += part + alignof(std::max_align_t);
  return {words, pool, entries, block};
}

// The key hash of the validate-only walk, which builds no directory and so needs no FNV-1a: any
// function of the decoded bytes finds equal keys in one equal-hash run; this one mixes eight bytes
// per multiply instead of one. `readable` says the eight bytes at each position are readable (a
// clean key in the padded input), so the tail is one masked load.
inline uint32_t scratch_hash(const char* p, size_t n, bool readable) {
  uint64_t h = uint64_t(n) * 0x9E3779B97F4A7C15ull;
  for (; n >= 8; p += 8, n -= 8) {
    uint64_t w;
    std::memcpy(&w, p, 8);
    h = (h ^ w) * 0xBF58476D1CE4E5B9ull;
    h ^= h >> 29;
  }
  if (n) {
    uint64_t w = 0;
    if (readable) {
      std::memcpy(&w, p, 8);
      w &= ~uint64_t(0) >> (64 - 8 * n);
    } else {
      std::memcpy(&w, p, n);
    }
    h = (h ^ w) * 0xBF58476D1CE4E5B9ull;
  }
  return uint32_t(h >> 32) ^ uint32_t(h);
}

// The validate-only writer: no tape, the same limits as ctape_writer (values, decoded text bytes,
// depth, token lengths) and the same sorted-run duplicate check, over a scratch stack of the open
// objects' keys (hash << 32 | position, and the key text, which stays valid for the walk: clean
// keys are input spans, escaped ones live in the retained pool or the oracle parser's string buffer).
// A matched template holds only its count: scratch slots are materialized only after a miss. Its hash is
// scratch_hash, not the directory FNV-1a (see directory_hash).
template<bool Structural = false> class basic_null_writer final {
  std::pmr::memory_resource* memory_;
  tape::arena_vec<uint64_t> pending_;
  tape::arena_vec<std::string_view> keys_;
  tape::arena_vec<uint8_t> pool_;
  const char* input_ = nullptr;
  myna::value_limits limits_;
  uint64_t values_ = 0, text_bytes_ = 0;
  tape::key_shape_cache* shapes_ = nullptr;

  template<class T> [[gnu::always_inline]] T* extend(tape::arena_vec<T>& array, size_t count = 1) {
    if constexpr (Structural) return array.extend_reserved(count);
    else return array.extend(memory_, count);
  }
  [[noreturn, gnu::noinline, gnu::cold]] static void limit(const char* what) { throw std::length_error(what); }
  [[gnu::always_inline]] void value() {
    if (values_ >= limits_.nodes) limit("tape value limit");
    ++values_;
  }
  [[gnu::always_inline]] void charge(size_t length) {
    if (length > tape::ctape::max_length) limit("tape text token limit");
    if (length > limits_.text_bytes - text_bytes_) limit("tape text limit");
    text_bytes_ += length;
  }
  [[gnu::always_inline]] void number(tape::ctape::span token) {
    if (token.length > tape::ctape::max_length) limit("tape text token limit");
    value();
  }
  [[gnu::noinline, gnu::cold]] void materialize(tape::key_shape_cache::frame& frame) {
    const auto& shape = shapes_->levels[frame.depth];
    if (frame.count) { extend(pending_, frame.count); extend(keys_, frame.count); }
    for (uint32_t i = 0; i < frame.count; ++i) {
      pending_[frame.first + i] = uint64_t(shape.keys[i].hash) << 32;
      keys_[frame.first + i] = {reinterpret_cast<const char*>(shape.keys[i].bytes), shape.keys[i].length};
    }
    frame.matched = false;
  }
  void close(size_t object, uint64_t count) {
    auto* frame = shapes_ ? shapes_->current(object) : nullptr;
    auto* shape = frame ? &shapes_->levels[frame->depth] : nullptr;
    bool hit = frame && frame->matched && count == shape->count;
    if (frame && frame->matched && !hit) materialize(*frame);
    size_t first = hit ? frame->first : pending_.size() - count;
    if (frame && (frame->count != count || frame->first != first))
      throw std::logic_error("object key count mismatch");
    if (count >= 2 && !hit) {
      uint64_t* e = pending_.data() + first;
      // Entry i names keys_[first + i]: hash << 32 | i sorts by (hash, position).
      for (size_t i = 0; i < count; ++i) e[i] |= i;
      if (count <= 24) {
        for (size_t i = 1; i < count; ++i) {
          uint64_t x = e[i];
          size_t j = i;
          while (j > 0 && e[j - 1] > x) { e[j] = e[j - 1]; --j; }
          e[j] = x;
        }
      } else {
        std::sort(e, e + count);
      }
      const std::string_view* k = keys_.data() + first;
      for (size_t i = 1; i < count; ++i) {
        if ((e[i] >> 32) != (e[i - 1] >> 32)) continue;
        std::string_view key = k[uint32_t(e[i])];
        for (size_t j = i; j > 0 && (e[j - 1] >> 32) == (e[i] >> 32); --j)
          if (k[uint32_t(e[j - 1])] == key) throw tape::ctape::duplicate_key();
      }
      if (shape && count <= tape::key_shape_cache::max_keys) {
        bool fits = true;
        for (size_t i = 0; i < count; ++i) fits &= k[i].size() <= tape::key_shape_cache::max_bytes;
        if (fits) {
          for (size_t rank = 0; rank < count; ++rank) {
            uint32_t ordinal = uint32_t(e[rank]);
            // Copy keys in source order below: prefix views may refer to this template.
            shape->rank[ordinal] = uint8_t(rank);
          }
          for (size_t i = 0; i < count; ++i)
            shape->keys[i].set(k[i], uint32_t(e[shape->rank[i]] >> 32));
          shape->count = uint32_t(count);
        }
      }
    }
    if (frame) --shapes_->active;
    pending_.truncate(first);
    keys_.truncate(first);
  }

 public:
  static constexpr bool retains_values = false;
  basic_null_writer(std::pmr::memory_resource* memory, myna::value_limits limits) : memory_(memory), limits_(limits) {}
  void shapes(tape::key_shape_cache* cache) { shapes_ = cache; if (cache) cache->start(); }
  basic_null_writer(const basic_null_writer&) = delete;
  basic_null_writer& operator=(const basic_null_writer&) = delete;

  void input(std::string_view input) { input_ = input.data(); }
  void reserve(size_t, size_t, size_t entries) {
    size_t pending = entries < 256 ? entries : 256;
    pending_.reserve(memory_, pending);
    keys_.reserve(memory_, pending);
  }
  void reserve_structural(size_t count, size_t input_bytes) {
    pending_.reserve(memory_, count / 2 + 1);
    keys_.reserve(memory_, count / 2 + 1);
    pool_.reserve(memory_, input_bytes + simdjson::SIMDJSON_PADDING);
  }
  void clear() {
    pending_.truncate(0); keys_.truncate(0); pool_.truncate(0); values_ = text_bytes_ = 0;
    if (shapes_) shapes_->start();
  }
  uint8_t* pool_reserve(size_t bytes) {
    if (bytes > UINT32_MAX - pool_.size()) limit("tape pool limit");
    pool_.reserve(memory_, pool_.size() + bytes);
    return pool_.data() + pool_.size();
  }
  void pool_commit(size_t bytes) { pool_.extend(memory_, bytes); }
  size_t pool_size() const { return pool_.size(); }
  const uint8_t* pool_data() const { return pool_.data(); }
  void string_owned(uint32_t, uint32_t length, tape::ctape::span, bool, bool) { charge(length); value(); }
  // The index is only the container kind: end() needs to know whether keys close with it.
  size_t begin(uint32_t kind, uint32_t depth, uint32_t = 0) {
    if (depth >= limits_.depth) limit("tape depth limit");
    value();
    if (kind != tape::ctape::kind_object) return 0;
    size_t object = values_;
    if (shapes_) shapes_->begin(object, pending_.size(), depth);
    return object;
  }
  void end(size_t object, uint64_t count) {
    if (object) close(object, count);
  }
  [[gnu::always_inline]] void key_text(size_t object, const uint8_t* text, uint32_t length, bool padded = false) {
    auto* frame = shapes_ ? shapes_->current(object) : nullptr;
    if (frame) {
      auto& shape = shapes_->levels[frame->depth];
      uint32_t ordinal = frame->count;
      if (frame->matched) {
        if (ordinal < shape.count && shape.keys[ordinal].equals(text, length, padded)) {
          ++frame->count;
          return;
        }
        materialize(*frame);
      }
      ++frame->count;
    }
    *extend(pending_) = uint64_t(myna_value_hash(text, length)) << 32;
    *extend(keys_) = {reinterpret_cast<const char*>(text), length};
  }
  [[gnu::always_inline]] uint32_t cached_key_ref(size_t object, uint32_t offset, uint32_t available) {
    auto* frame = shapes_ ? shapes_->current(object) : nullptr;
    if (!frame || !frame->matched) return UINT32_MAX;
    const auto& shape = shapes_->levels[frame->depth];
    if (frame->count >= shape.count) return UINT32_MAX;
    const auto& key = shape.keys[frame->count];
    const auto* text = reinterpret_cast<const uint8_t*>(input_) + offset;
    if (!key.clean || available <= key.length || text[key.length] != '"' || !key.equals(text, key.length, true))
      return UINT32_MAX;
    ++frame->count;
    charge(key.length); value();
    return key.length;
  }
  void null() { value(); }
  void boolean(bool) { value(); }
  void parsed_number(uint32_t, uint64_t, tape::ctape::span) {}
  void commit_number(tape::ctape::span token) { number(token); }
  void rollback_number() {}
  void integer(int64_t, tape::ctape::span token) { number(token); }
  void unsigned_integer(uint64_t, tape::ctape::span token) { number(token); }
  void floating(double, tape::ctape::span token) { number(token); }
  void decimal_ref(tape::ctape::span token) {
    charge(token.length);
    value();
  }
  [[gnu::always_inline]] void string_ref(tape::ctape::span decoded, bool, bool) {
    charge(decoded.length);
    value();
  }
  void string(std::string_view decoded, tape::ctape::span, bool, bool) {
    charge(decoded.size());
    value();
  }
  uint64_t value_count() const { return values_; }
};

using null_writer = basic_null_writer<false>;
using structural_null_writer = basic_null_writer<true>;

} // namespace truffledata::json
#endif
